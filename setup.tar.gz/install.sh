#!/bin/sh

# time zone to set
TIME_ZONE=UTC

###############################

tar xz -C / -f data/opkg.tar.gz

opkg install data/libpolarssl.ipk
opkg install data/libcurl.ipk
opkg install data/curl.ipk

opkg update

opkg install socat

rm -f /etc/TZ
echo $TIME_ZONE > /etc/TZ

mkdir /www/cgi-bin
cp data/relay.cgi /www/cgi-bin
cp data/prefs.cgi /www/cgi-bin

cp data/broadcast.sh /

sh /etc/init.d/cron start
sh /etc/init.d/cron enable
mkdir -p /var/spool/cron

crontab -l | { cat; echo "*/2 * * * * /broadcast.sh"; } | crontab -

sed -ie '/^exit/d' /etc/rc.local

reboot
